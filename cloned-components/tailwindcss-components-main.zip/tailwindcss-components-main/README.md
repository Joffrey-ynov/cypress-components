# tailwindcss-components
Some UI components crafted with Tailwind CSS & Alpine JS when needed to keep it simple.
Feel free to use the components and star the repository.
