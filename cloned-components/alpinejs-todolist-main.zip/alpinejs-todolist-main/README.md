# alpinejs-todolist

A simple todolist with Alpine JS & Tailwind CSS